defmodule TimeManager.Mailer do
  use Swoosh.Mailer, otp_app: :time_manager
end
